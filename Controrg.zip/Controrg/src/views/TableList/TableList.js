import React from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardBody from "components/Card/CardBody.js";

const styles = {
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  }
};

const useStyles = makeStyles(styles);

export default function TableList() {
  const classes = useStyles();
  return (
    <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">
            <h4 className={classes.cardTitleWhite}>Company Employees Table</h4>
            <p className={classes.cardCategoryWhite}>
              The Company's Employee List Showing their Personal Info and Salary Details
            </p>
          </CardHeader>
          <CardBody>
            <Table
              tableHeaderColor="primary"
              tableHead={["Name", "Country", "City", "Salary"]}
              tableData={[
                ["Owais Amjad", "Pakistan", "Rawalpindi", "$36,738"],
                ["Faizan Ahmad", "America", "LA", "$23,789"],
                ["Talha Fiaz", "Netherlands", "Baileux", "$56,142"],
                ["Haseeb Baig", "Jammu and Kashmir", "Balalkot", "$38,735"],
                ["Abdul Basit", "Kuwait", "Jadda", "$63,542"],
                ["Hamza Akhtar", "Malaysia", "Colalampoor", "$78,615"]
              ]}
            />
          </CardBody>
        </Card>
      </GridItem>
      <GridItem xs={12} sm={12} md={12}>
        <Card plain>
          <CardHeader plain color="primary">
            <h4 className={classes.cardTitleWhite}>
              List of Internees
            </h4>
            <p className={classes.cardCategoryWhite}>
              The list of internees with no experience
            </p>
          </CardHeader>
          <CardBody>
            <Table
              tableHeaderColor="primary"
              tableHead={["ID", "Name", "Country", "City", "Salary"]}
              tableData={[
                ["1", "Saima", "Yaman", "Niger", "$5000"],
                ["2", "Rabia", "Iraq", "Curaçao", "$5300"],
                ["3", "Jahanzeb", "Bahrain", "Netherlands", "$6000"],
                [
                  "4",
                  "Kaleem",
                  "Kuwait",
                  "Korea, South",
                  "$6200"
                ],
                [
                  "5",
                  "Saleem",
                  "Saudia Arab",
                  "Malawi",
                  "$5500"
                ],
                ["6", "Rafeeq", "America", "Chile", "$5600"]
              ]}
            />
          </CardBody>
        </Card>
      </GridItem>
    </GridContainer>
  );
}
